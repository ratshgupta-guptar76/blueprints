module SSCS_2026_02 (
    A44_GND,
    A44_VDD,
    A44_CLKS,
    A44_DOUT[7],
    A44_DOUT[6],
    A44_DOUT[5],
    A44_DOUT[4],
    A44_DOUT[3],
    A44_DOUT[2],
    A44_DOUT[1],
    A44_DOUT[0],
    A44_VREFN,
    A44_VINN,
    A44_VINP,
    A44_VREFP,
    B04_GND,
    B04_VDD,
    B04_Vin,
    B04_Vbpf,
    B04_Venvelope,
    B04_Vthreshold,
    B04_Vtrigger,
    B04_sda,
    B04_scl,
    B04_en,
    C01_VSS,
    C01_INP_TELESCOPIC,
    C01_INP_FOLDED,
    C01_OUT_TELESCOPIC,
    C01_OUT_FOLDED,
    C01_INP_5T,
    C01_INN_TELESCOPIC,
    C01_INN_FOLDED,
    C01_PROG_ENA,
    C01_SCAN_IN,
    C01_VDD,
    C01_CLK,
    C01_IBIAS,
    C01_SCAN_OUT,
    C01_IN_CS,
    C01_OUT_CS,
    C01_INN_5T,
    C01_OUT_5T,
    A07_VSS,
    A07_clk,
    A07_rst_n,
    A07_a_bit,
    A07_w_bit,
    A07_start,
    A07_cont,
    A07_P_minus1[0],
    A07_P_minus1[1],
    A07_P_minus1[2],
    A07_y_bit,
    A07_done,
    A07_busy,
    A07_VDD
);
  inout A44_GND;
  inout A44_VDD;
  inout A44_CLKS;
  inout A44_DOUT[7];
  inout A44_DOUT[6];
  inout A44_DOUT[5];
  inout A44_DOUT[4];
  inout A44_DOUT[3];
  inout A44_DOUT[2];
  inout A44_DOUT[1];
  inout A44_DOUT[0];
  inout A44_VREFN;
  inout A44_VINN;
  inout A44_VINP;
  inout A44_VREFP;
  inout B04_GND;
  inout B04_VDD;
  inout B04_Vin;
  inout B04_Vbpf;
  inout B04_Venvelope;
  inout B04_Vthreshold;
  inout B04_Vtrigger;
  inout B04_sda;
  inout B04_scl;
  inout B04_en;
  inout C01_VSS;
  inout C01_INP_TELESCOPIC;
  inout C01_INP_FOLDED;
  inout C01_OUT_TELESCOPIC;
  inout C01_OUT_FOLDED;
  inout C01_INP_5T;
  inout C01_INN_TELESCOPIC;
  inout C01_INN_FOLDED;
  inout C01_PROG_ENA;
  inout C01_SCAN_IN;
  inout C01_VDD;
  inout C01_CLK;
  inout C01_IBIAS;
  inout C01_SCAN_OUT;
  inout C01_IN_CS;
  inout C01_OUT_CS;
  inout C01_INN_5T;
  inout C01_OUT_5T;
  inout A07_VSS;
  inout A07_clk;
  inout A07_rst_n;
  inout A07_a_bit;
  inout A07_w_bit;
  inout A07_start;
  inout A07_cont;
  inout A07_P_minus1[0];
  inout A07_P_minus1[1];
  inout A07_P_minus1[2];
  inout A07_y_bit;
  inout A07_done;
  inout A07_busy;
  inout A07_VDD;
  wire A07_P_minus1[0]__CORE;
  wire A07_P_minus1[1]__CORE;
  wire A07_P_minus1[2]__CORE;
  wire A07_P_minus1_PD[0];
  wire A07_P_minus1_PD[1];
  wire A07_P_minus1_PD[2];
  wire A07_P_minus1_PU[0];
  wire A07_P_minus1_PU[1];
  wire A07_P_minus1_PU[2];
  wire A07_a_bit_PD;
  wire A07_a_bit_PU;
  wire A07_a_bit__CORE;
  wire A07_busy_CS;
  wire A07_busy_IE;
  wire A07_busy_IN;
  wire A07_busy_OE;
  wire A07_busy_OUT;
  wire A07_busy_PD;
  wire A07_busy_PDRV0;
  wire A07_busy_PDRV1;
  wire A07_busy_PU;
  wire A07_busy_SL;
  wire A07_clk_PD;
  wire A07_clk_PU;
  wire A07_clk__CORE;
  wire A07_cont_PD;
  wire A07_cont_PU;
  wire A07_cont__CORE;
  wire A07_done_CS;
  wire A07_done_IE;
  wire A07_done_IN;
  wire A07_done_OE;
  wire A07_done_OUT;
  wire A07_done_PD;
  wire A07_done_PDRV0;
  wire A07_done_PDRV1;
  wire A07_done_PU;
  wire A07_done_SL;
  wire A07_rst_n_PD;
  wire A07_rst_n_PU;
  wire A07_rst_n__CORE;
  wire A07_start_PD;
  wire A07_start_PU;
  wire A07_start__CORE;
  wire A07_w_bit_PD;
  wire A07_w_bit_PU;
  wire A07_w_bit__CORE;
  wire A07_y_bit_CS;
  wire A07_y_bit_IE;
  wire A07_y_bit_IN;
  wire A07_y_bit_OE;
  wire A07_y_bit_OUT;
  wire A07_y_bit_PD;
  wire A07_y_bit_PDRV0;
  wire A07_y_bit_PDRV1;
  wire A07_y_bit_PU;
  wire A07_y_bit_SL;
  wire A44_CLKS_PD;
  wire A44_CLKS_PU;
  wire A44_CLKS__CORE;
  wire A44_DOUT_CS[0];
  wire A44_DOUT_CS[1];
  wire A44_DOUT_CS[2];
  wire A44_DOUT_CS[3];
  wire A44_DOUT_CS[4];
  wire A44_DOUT_CS[5];
  wire A44_DOUT_CS[6];
  wire A44_DOUT_CS[7];
  wire A44_DOUT_IE[0];
  wire A44_DOUT_IE[1];
  wire A44_DOUT_IE[2];
  wire A44_DOUT_IE[3];
  wire A44_DOUT_IE[4];
  wire A44_DOUT_IE[5];
  wire A44_DOUT_IE[6];
  wire A44_DOUT_IE[7];
  wire A44_DOUT_IN[0];
  wire A44_DOUT_IN[1];
  wire A44_DOUT_IN[2];
  wire A44_DOUT_IN[3];
  wire A44_DOUT_IN[4];
  wire A44_DOUT_IN[5];
  wire A44_DOUT_IN[6];
  wire A44_DOUT_IN[7];
  wire A44_DOUT_OE[0];
  wire A44_DOUT_OE[1];
  wire A44_DOUT_OE[2];
  wire A44_DOUT_OE[3];
  wire A44_DOUT_OE[4];
  wire A44_DOUT_OE[5];
  wire A44_DOUT_OE[6];
  wire A44_DOUT_OE[7];
  wire A44_DOUT_OUT[0];
  wire A44_DOUT_OUT[1];
  wire A44_DOUT_OUT[2];
  wire A44_DOUT_OUT[3];
  wire A44_DOUT_OUT[4];
  wire A44_DOUT_OUT[5];
  wire A44_DOUT_OUT[6];
  wire A44_DOUT_OUT[7];
  wire A44_DOUT_PDRV0[0];
  wire A44_DOUT_PDRV0[1];
  wire A44_DOUT_PDRV0[2];
  wire A44_DOUT_PDRV0[3];
  wire A44_DOUT_PDRV0[4];
  wire A44_DOUT_PDRV0[5];
  wire A44_DOUT_PDRV0[6];
  wire A44_DOUT_PDRV0[7];
  wire A44_DOUT_PDRV1[0];
  wire A44_DOUT_PDRV1[1];
  wire A44_DOUT_PDRV1[2];
  wire A44_DOUT_PDRV1[3];
  wire A44_DOUT_PDRV1[4];
  wire A44_DOUT_PDRV1[5];
  wire A44_DOUT_PDRV1[6];
  wire A44_DOUT_PDRV1[7];
  wire A44_DOUT_PD[0];
  wire A44_DOUT_PD[1];
  wire A44_DOUT_PD[2];
  wire A44_DOUT_PD[3];
  wire A44_DOUT_PD[4];
  wire A44_DOUT_PD[5];
  wire A44_DOUT_PD[6];
  wire A44_DOUT_PD[7];
  wire A44_DOUT_PU[0];
  wire A44_DOUT_PU[1];
  wire A44_DOUT_PU[2];
  wire A44_DOUT_PU[3];
  wire A44_DOUT_PU[4];
  wire A44_DOUT_PU[5];
  wire A44_DOUT_PU[6];
  wire A44_DOUT_PU[7];
  wire A44_DOUT_SL[0];
  wire A44_DOUT_SL[1];
  wire A44_DOUT_SL[2];
  wire A44_DOUT_SL[3];
  wire A44_DOUT_SL[4];
  wire A44_DOUT_SL[5];
  wire A44_DOUT_SL[6];
  wire A44_DOUT_SL[7];
  wire B04_Vtrigger_CS;
  wire B04_Vtrigger_IE;
  wire B04_Vtrigger_IN;
  wire B04_Vtrigger_OE;
  wire B04_Vtrigger_OUT;
  wire B04_Vtrigger_PD;
  wire B04_Vtrigger_PDRV0;
  wire B04_Vtrigger_PDRV1;
  wire B04_Vtrigger_PU;
  wire B04_Vtrigger_SL;
  wire B04_en_PD;
  wire B04_en_PU;
  wire B04_en__CORE;
  wire B04_scl_PD;
  wire B04_scl_PU;
  wire B04_scl__CORE;
  wire B04_sda_CS;
  wire B04_sda_IE;
  wire B04_sda_PD;
  wire B04_sda_PDRV0;
  wire B04_sda_PDRV1;
  wire B04_sda_PU;
  wire B04_sda_SL;
  wire B04_sda_in;
  wire B04_sda_oe;
  wire B04_sda_out;
  wire C01_CLK_PD;
  wire C01_CLK_PU;
  wire C01_CLK__CORE;
  wire C01_PROG_ENA_PD;
  wire C01_PROG_ENA_PU;
  wire C01_PROG_ENA__CORE;
  wire C01_SCAN_IN_PD;
  wire C01_SCAN_IN_PU;
  wire C01_SCAN_IN__CORE;
  wire C01_SCAN_OUT_CS;
  wire C01_SCAN_OUT_IE;
  wire C01_SCAN_OUT_IN;
  wire C01_SCAN_OUT_OE;
  wire C01_SCAN_OUT_OUT;
  wire C01_SCAN_OUT_PD;
  wire C01_SCAN_OUT_PDRV0;
  wire C01_SCAN_OUT_PDRV1;
  wire C01_SCAN_OUT_PU;
  wire C01_SCAN_OUT_SL;
  SSCS_2026_02_padring PADRING (.E01(C01_VDD), .E02(C01_SCAN_IN), .E02_PD(C01_SCAN_IN_PD), .E02_PU(C01_SCAN_IN_PU), .E02_Y(C01_SCAN_IN__CORE), .E03(C01_PROG_ENA), .E03_PD(C01_PROG_ENA_PD), .E03_PU(C01_PROG_ENA_PU), .E03_Y(C01_PROG_ENA__CORE), .E04(C01_INN_FOLDED), .E04_ASIG5V(C01_INN_FOLDED), .E05(C01_INN_TELESCOPIC), .E05_ASIG5V(C01_INN_TELESCOPIC), .E06(C01_INP_5T), .E06_ASIG5V(C01_INP_5T), .E07(C01_OUT_FOLDED), .E07_ASIG5V(C01_OUT_FOLDED), .E08(C01_OUT_TELESCOPIC), .E08_ASIG5V(C01_OUT_TELESCOPIC), .E09(C01_INP_FOLDED), .E09_ASIG5V(C01_INP_FOLDED), .E10(C01_INP_TELESCOPIC), .E10_ASIG5V(C01_INP_TELESCOPIC), .E11(C01_VSS), .E12(B04_GND), .E13(B04_VDD), .E14(B04_Vin), .E14_ASIG5V(B04_Vin), .E15(B04_Vbpf), .E15_ASIG5V(B04_Vbpf), .E16(B04_Venvelope), .E16_ASIG5V(B04_Venvelope), .E17(B04_Vthreshold), .E17_ASIG5V(B04_Vthreshold), .E18(B04_Vtrigger), .E18_A(B04_Vtrigger_OUT), .E18_CS(B04_Vtrigger_CS), .E18_IE(B04_Vtrigger_IE), .E18_OE(B04_Vtrigger_OE), .E18_PD(B04_Vtrigger_PD), .E18_PDRV0(B04_Vtrigger_PDRV0), .E18_PDRV1(B04_Vtrigger_PDRV1), .E18_PU(B04_Vtrigger_PU), .E18_SL(B04_Vtrigger_SL), .E18_Y(B04_Vtrigger_IN), .E19(B04_sda), .E19_A(B04_sda_out), .E19_CS(B04_sda_CS), .E19_IE(B04_sda_IE), .E19_OE(B04_sda_oe), .E19_PD(B04_sda_PD), .E19_PDRV0(B04_sda_PDRV0), .E19_PDRV1(B04_sda_PDRV1), .E19_PU(B04_sda_PU), .E19_SL(B04_sda_SL), .E19_Y(B04_sda_in), .E20(B04_scl), .E20_PD(B04_scl_PD), .E20_PU(B04_scl_PU), .E20_Y(B04_scl__CORE), .E21(B04_en), .E21_PD(B04_en_PD), .E21_PU(B04_en_PU), .E21_Y(B04_en__CORE), .N01(A44_VREFN), .N01_ASIG5V(A44_VREFN), .N02(A44_VINN), .N02_ASIG5V(A44_VINN), .N03(A44_VINP), .N03_ASIG5V(A44_VINP), .N04(A44_VREFP), .N04_ASIG5V(A44_VREFP), .S01(A07_done), .S01_A(A07_done_OUT), .S01_CS(A07_done_CS), .S01_IE(A07_done_IE), .S01_OE(A07_done_OE), .S01_PD(A07_done_PD), .S01_PDRV0(A07_done_PDRV0), .S01_PDRV1(A07_done_PDRV1), .S01_PU(A07_done_PU), .S01_SL(A07_done_SL), .S01_Y(A07_done_IN), .S02(A07_busy), .S02_A(A07_busy_OUT), .S02_CS(A07_busy_CS), .S02_IE(A07_busy_IE), .S02_OE(A07_busy_OE), .S02_PD(A07_busy_PD), .S02_PDRV0(A07_busy_PDRV0), .S02_PDRV1(A07_busy_PDRV1), .S02_PU(A07_busy_PU), .S02_SL(A07_busy_SL), .S02_Y(A07_busy_IN), .S03(A07_VDD), .S16(C01_OUT_5T), .S16_ASIG5V(C01_OUT_5T), .S17(C01_INN_5T), .S17_ASIG5V(C01_INN_5T), .S18(C01_OUT_CS), .S18_ASIG5V(C01_OUT_CS), .S19(C01_IN_CS), .S19_ASIG5V(C01_IN_CS), .S20(C01_SCAN_OUT), .S20_A(C01_SCAN_OUT_OUT), .S20_CS(C01_SCAN_OUT_CS), .S20_IE(C01_SCAN_OUT_IE), .S20_OE(C01_SCAN_OUT_OE), .S20_PD(C01_SCAN_OUT_PD), .S20_PDRV0(C01_SCAN_OUT_PDRV0), .S20_PDRV1(C01_SCAN_OUT_PDRV1), .S20_PU(C01_SCAN_OUT_PU), .S20_SL(C01_SCAN_OUT_SL), .S20_Y(C01_SCAN_OUT_IN), .S21(C01_IBIAS), .S21_ASIG5V(C01_IBIAS), .S22(C01_CLK), .S22_PD(C01_CLK_PD), .S22_PU(C01_CLK_PU), .S22_Y(C01_CLK__CORE), .W01(A07_y_bit), .W01_A(A07_y_bit_OUT), .W01_CS(A07_y_bit_CS), .W01_IE(A07_y_bit_IE), .W01_OE(A07_y_bit_OE), .W01_PD(A07_y_bit_PD), .W01_PDRV0(A07_y_bit_PDRV0), .W01_PDRV1(A07_y_bit_PDRV1), .W01_PU(A07_y_bit_PU), .W01_SL(A07_y_bit_SL), .W01_Y(A07_y_bit_IN), .W02(A07_P_minus1[2]), .W02_PD(A07_P_minus1_PD[2]), .W02_PU(A07_P_minus1_PU[2]), .W02_Y(A07_P_minus1[2]__CORE), .W03(A07_P_minus1[1]), .W03_PD(A07_P_minus1_PD[1]), .W03_PU(A07_P_minus1_PU[1]), .W03_Y(A07_P_minus1[1]__CORE), .W04(A07_P_minus1[0]), .W04_PD(A07_P_minus1_PD[0]), .W04_PU(A07_P_minus1_PU[0]), .W04_Y(A07_P_minus1[0]__CORE), .W05(A07_cont), .W05_PD(A07_cont_PD), .W05_PU(A07_cont_PU), .W05_Y(A07_cont__CORE), .W06(A07_start), .W06_PD(A07_start_PD), .W06_PU(A07_start_PU), .W06_Y(A07_start__CORE), .W07(A07_w_bit), .W07_PD(A07_w_bit_PD), .W07_PU(A07_w_bit_PU), .W07_Y(A07_w_bit__CORE), .W08(A07_a_bit), .W08_PD(A07_a_bit_PD), .W08_PU(A07_a_bit_PU), .W08_Y(A07_a_bit__CORE), .W09(A07_rst_n), .W09_PD(A07_rst_n_PD), .W09_PU(A07_rst_n_PU), .W09_Y(A07_rst_n__CORE), .W10(A07_clk), .W10_PD(A07_clk_PD), .W10_PU(A07_clk_PU), .W10_Y(A07_clk__CORE), .W11(A07_VSS), .W12(A44_GND), .W13(A44_VDD), .W14(A44_CLKS), .W14_PD(A44_CLKS_PD), .W14_PU(A44_CLKS_PU), .W14_Y(A44_CLKS__CORE), .W15(A44_DOUT[7]), .W15_A(A44_DOUT_OUT[7]), .W15_CS(A44_DOUT_CS[7]), .W15_IE(A44_DOUT_IE[7]), .W15_OE(A44_DOUT_OE[7]), .W15_PD(A44_DOUT_PD[7]), .W15_PDRV0(A44_DOUT_PDRV0[7]), .W15_PDRV1(A44_DOUT_PDRV1[7]), .W15_PU(A44_DOUT_PU[7]), .W15_SL(A44_DOUT_SL[7]), .W15_Y(A44_DOUT_IN[7]), .W16(A44_DOUT[6]), .W16_A(A44_DOUT_OUT[6]), .W16_CS(A44_DOUT_CS[6]), .W16_IE(A44_DOUT_IE[6]), .W16_OE(A44_DOUT_OE[6]), .W16_PD(A44_DOUT_PD[6]), .W16_PDRV0(A44_DOUT_PDRV0[6]), .W16_PDRV1(A44_DOUT_PDRV1[6]), .W16_PU(A44_DOUT_PU[6]), .W16_SL(A44_DOUT_SL[6]), .W16_Y(A44_DOUT_IN[6]), .W17(A44_DOUT[5]), .W17_A(A44_DOUT_OUT[5]), .W17_CS(A44_DOUT_CS[5]), .W17_IE(A44_DOUT_IE[5]), .W17_OE(A44_DOUT_OE[5]), .W17_PD(A44_DOUT_PD[5]), .W17_PDRV0(A44_DOUT_PDRV0[5]), .W17_PDRV1(A44_DOUT_PDRV1[5]), .W17_PU(A44_DOUT_PU[5]), .W17_SL(A44_DOUT_SL[5]), .W17_Y(A44_DOUT_IN[5]), .W18(A44_DOUT[4]), .W18_A(A44_DOUT_OUT[4]), .W18_CS(A44_DOUT_CS[4]), .W18_IE(A44_DOUT_IE[4]), .W18_OE(A44_DOUT_OE[4]), .W18_PD(A44_DOUT_PD[4]), .W18_PDRV0(A44_DOUT_PDRV0[4]), .W18_PDRV1(A44_DOUT_PDRV1[4]), .W18_PU(A44_DOUT_PU[4]), .W18_SL(A44_DOUT_SL[4]), .W18_Y(A44_DOUT_IN[4]), .W19(A44_DOUT[3]), .W19_A(A44_DOUT_OUT[3]), .W19_CS(A44_DOUT_CS[3]), .W19_IE(A44_DOUT_IE[3]), .W19_OE(A44_DOUT_OE[3]), .W19_PD(A44_DOUT_PD[3]), .W19_PDRV0(A44_DOUT_PDRV0[3]), .W19_PDRV1(A44_DOUT_PDRV1[3]), .W19_PU(A44_DOUT_PU[3]), .W19_SL(A44_DOUT_SL[3]), .W19_Y(A44_DOUT_IN[3]), .W20(A44_DOUT[2]), .W20_A(A44_DOUT_OUT[2]), .W20_CS(A44_DOUT_CS[2]), .W20_IE(A44_DOUT_IE[2]), .W20_OE(A44_DOUT_OE[2]), .W20_PD(A44_DOUT_PD[2]), .W20_PDRV0(A44_DOUT_PDRV0[2]), .W20_PDRV1(A44_DOUT_PDRV1[2]), .W20_PU(A44_DOUT_PU[2]), .W20_SL(A44_DOUT_SL[2]), .W20_Y(A44_DOUT_IN[2]), .W21(A44_DOUT[1]), .W21_A(A44_DOUT_OUT[1]), .W21_CS(A44_DOUT_CS[1]), .W21_IE(A44_DOUT_IE[1]), .W21_OE(A44_DOUT_OE[1]), .W21_PD(A44_DOUT_PD[1]), .W21_PDRV0(A44_DOUT_PDRV0[1]), .W21_PDRV1(A44_DOUT_PDRV1[1]), .W21_PU(A44_DOUT_PU[1]), .W21_SL(A44_DOUT_SL[1]), .W21_Y(A44_DOUT_IN[1]), .W22(A44_DOUT[0]), .W22_A(A44_DOUT_OUT[0]), .W22_CS(A44_DOUT_CS[0]), .W22_IE(A44_DOUT_IE[0]), .W22_OE(A44_DOUT_OE[0]), .W22_PD(A44_DOUT_PD[0]), .W22_PDRV0(A44_DOUT_PDRV0[0]), .W22_PDRV1(A44_DOUT_PDRV1[0]), .W22_PU(A44_DOUT_PU[0]), .W22_SL(A44_DOUT_SL[0]), .W22_Y(A44_DOUT_IN[0]));
  A44_A A44_PROJECT (.GND(A44_GND), .VDD(A44_VDD), .CLKS_PU(A44_CLKS_PU), .CLKS_PD(A44_CLKS_PD), .CLKS(A44_CLKS__CORE), .DOUT_CS[7](A44_DOUT_CS[7]), .DOUT_SL[7](A44_DOUT_SL[7]), .DOUT_IE[7](A44_DOUT_IE[7]), .DOUT_OE[7](A44_DOUT_OE[7]), .DOUT_PU[7](A44_DOUT_PU[7]), .DOUT_PD[7](A44_DOUT_PD[7]), .DOUT_OUT[7](A44_DOUT_OUT[7]), .DOUT_PDRV0[7](A44_DOUT_PDRV0[7]), .DOUT_PDRV1[7](A44_DOUT_PDRV1[7]), .DOUT_IN[7](A44_DOUT_IN[7]), .DOUT_CS[6](A44_DOUT_CS[6]), .DOUT_SL[6](A44_DOUT_SL[6]), .DOUT_IE[6](A44_DOUT_IE[6]), .DOUT_OE[6](A44_DOUT_OE[6]), .DOUT_PU[6](A44_DOUT_PU[6]), .DOUT_PD[6](A44_DOUT_PD[6]), .DOUT_OUT[6](A44_DOUT_OUT[6]), .DOUT_PDRV0[6](A44_DOUT_PDRV0[6]), .DOUT_PDRV1[6](A44_DOUT_PDRV1[6]), .DOUT_IN[6](A44_DOUT_IN[6]), .DOUT_CS[5](A44_DOUT_CS[5]), .DOUT_SL[5](A44_DOUT_SL[5]), .DOUT_IE[5](A44_DOUT_IE[5]), .DOUT_OE[5](A44_DOUT_OE[5]), .DOUT_PU[5](A44_DOUT_PU[5]), .DOUT_PD[5](A44_DOUT_PD[5]), .DOUT_OUT[5](A44_DOUT_OUT[5]), .DOUT_PDRV0[5](A44_DOUT_PDRV0[5]), .DOUT_PDRV1[5](A44_DOUT_PDRV1[5]), .DOUT_IN[5](A44_DOUT_IN[5]), .DOUT_CS[4](A44_DOUT_CS[4]), .DOUT_SL[4](A44_DOUT_SL[4]), .DOUT_IE[4](A44_DOUT_IE[4]), .DOUT_OE[4](A44_DOUT_OE[4]), .DOUT_PU[4](A44_DOUT_PU[4]), .DOUT_PD[4](A44_DOUT_PD[4]), .DOUT_OUT[4](A44_DOUT_OUT[4]), .DOUT_PDRV0[4](A44_DOUT_PDRV0[4]), .DOUT_PDRV1[4](A44_DOUT_PDRV1[4]), .DOUT_IN[4](A44_DOUT_IN[4]), .DOUT_CS[3](A44_DOUT_CS[3]), .DOUT_SL[3](A44_DOUT_SL[3]), .DOUT_IE[3](A44_DOUT_IE[3]), .DOUT_OE[3](A44_DOUT_OE[3]), .DOUT_PU[3](A44_DOUT_PU[3]), .DOUT_PD[3](A44_DOUT_PD[3]), .DOUT_OUT[3](A44_DOUT_OUT[3]), .DOUT_PDRV0[3](A44_DOUT_PDRV0[3]), .DOUT_PDRV1[3](A44_DOUT_PDRV1[3]), .DOUT_IN[3](A44_DOUT_IN[3]), .DOUT_CS[2](A44_DOUT_CS[2]), .DOUT_SL[2](A44_DOUT_SL[2]), .DOUT_IE[2](A44_DOUT_IE[2]), .DOUT_OE[2](A44_DOUT_OE[2]), .DOUT_PU[2](A44_DOUT_PU[2]), .DOUT_PD[2](A44_DOUT_PD[2]), .DOUT_OUT[2](A44_DOUT_OUT[2]), .DOUT_PDRV0[2](A44_DOUT_PDRV0[2]), .DOUT_PDRV1[2](A44_DOUT_PDRV1[2]), .DOUT_IN[2](A44_DOUT_IN[2]), .DOUT_CS[1](A44_DOUT_CS[1]), .DOUT_SL[1](A44_DOUT_SL[1]), .DOUT_IE[1](A44_DOUT_IE[1]), .DOUT_OE[1](A44_DOUT_OE[1]), .DOUT_PU[1](A44_DOUT_PU[1]), .DOUT_PD[1](A44_DOUT_PD[1]), .DOUT_OUT[1](A44_DOUT_OUT[1]), .DOUT_PDRV0[1](A44_DOUT_PDRV0[1]), .DOUT_PDRV1[1](A44_DOUT_PDRV1[1]), .DOUT_IN[1](A44_DOUT_IN[1]), .DOUT_CS[0](A44_DOUT_CS[0]), .DOUT_SL[0](A44_DOUT_SL[0]), .DOUT_IE[0](A44_DOUT_IE[0]), .DOUT_OE[0](A44_DOUT_OE[0]), .DOUT_PU[0](A44_DOUT_PU[0]), .DOUT_PD[0](A44_DOUT_PD[0]), .DOUT_OUT[0](A44_DOUT_OUT[0]), .DOUT_PDRV0[0](A44_DOUT_PDRV0[0]), .DOUT_PDRV1[0](A44_DOUT_PDRV1[0]), .DOUT_IN[0](A44_DOUT_IN[0]), .VREFN(A44_VREFN), .VINN(A44_VINN), .VINP(A44_VINP), .VREFP(A44_VREFP));
  B04_TOP B04_PROJECT (.GND(B04_GND), .VDD(B04_VDD), .Vin(B04_Vin), .Vbpf(B04_Vbpf), .Venvelope(B04_Venvelope), .Vthreshold(B04_Vthreshold), .Vtrigger_CS(B04_Vtrigger_CS), .Vtrigger_SL(B04_Vtrigger_SL), .Vtrigger_IE(B04_Vtrigger_IE), .Vtrigger_OE(B04_Vtrigger_OE), .Vtrigger_PU(B04_Vtrigger_PU), .Vtrigger_PD(B04_Vtrigger_PD), .Vtrigger_OUT(B04_Vtrigger_OUT), .Vtrigger_PDRV0(B04_Vtrigger_PDRV0), .Vtrigger_PDRV1(B04_Vtrigger_PDRV1), .Vtrigger_IN(B04_Vtrigger_IN), .sda_CS(B04_sda_CS), .sda_SL(B04_sda_SL), .sda_IE(B04_sda_IE), .sda_oe(B04_sda_oe), .sda_PU(B04_sda_PU), .sda_PD(B04_sda_PD), .sda_out(B04_sda_out), .sda_PDRV0(B04_sda_PDRV0), .sda_PDRV1(B04_sda_PDRV1), .sda_in(B04_sda_in), .scl_PU(B04_scl_PU), .scl_PD(B04_scl_PD), .scl(B04_scl__CORE), .en_PU(B04_en_PU), .en_PD(B04_en_PD), .en(B04_en__CORE));
  C01_DUT C01_PROJECT (.VSS(C01_VSS), .INP_TELESCOPIC(C01_INP_TELESCOPIC), .INP_FOLDED(C01_INP_FOLDED), .OUT_TELESCOPIC(C01_OUT_TELESCOPIC), .OUT_FOLDED(C01_OUT_FOLDED), .INP_5T(C01_INP_5T), .INN_TELESCOPIC(C01_INN_TELESCOPIC), .INN_FOLDED(C01_INN_FOLDED), .PROG_ENA_PU(C01_PROG_ENA_PU), .PROG_ENA_PD(C01_PROG_ENA_PD), .PROG_ENA(C01_PROG_ENA__CORE), .SCAN_IN_PU(C01_SCAN_IN_PU), .SCAN_IN_PD(C01_SCAN_IN_PD), .SCAN_IN(C01_SCAN_IN__CORE), .VDD(C01_VDD), .CLK_PU(C01_CLK_PU), .CLK_PD(C01_CLK_PD), .CLK(C01_CLK__CORE), .IBIAS(C01_IBIAS), .SCAN_OUT_CS(C01_SCAN_OUT_CS), .SCAN_OUT_SL(C01_SCAN_OUT_SL), .SCAN_OUT_IE(C01_SCAN_OUT_IE), .SCAN_OUT_OE(C01_SCAN_OUT_OE), .SCAN_OUT_PU(C01_SCAN_OUT_PU), .SCAN_OUT_PD(C01_SCAN_OUT_PD), .SCAN_OUT_OUT(C01_SCAN_OUT_OUT), .SCAN_OUT_PDRV0(C01_SCAN_OUT_PDRV0), .SCAN_OUT_PDRV1(C01_SCAN_OUT_PDRV1), .SCAN_OUT_IN(C01_SCAN_OUT_IN), .IN_CS(C01_IN_CS), .OUT_CS(C01_OUT_CS), .INN_5T(C01_INN_5T), .OUT_5T(C01_OUT_5T));
  A07_dcim_top A07_PROJECT (.VSS(A07_VSS), .clk_PU(A07_clk_PU), .clk_PD(A07_clk_PD), .clk(A07_clk__CORE), .rst_n_PU(A07_rst_n_PU), .rst_n_PD(A07_rst_n_PD), .rst_n(A07_rst_n__CORE), .a_bit_PU(A07_a_bit_PU), .a_bit_PD(A07_a_bit_PD), .a_bit(A07_a_bit__CORE), .w_bit_PU(A07_w_bit_PU), .w_bit_PD(A07_w_bit_PD), .w_bit(A07_w_bit__CORE), .start_PU(A07_start_PU), .start_PD(A07_start_PD), .start(A07_start__CORE), .cont_PU(A07_cont_PU), .cont_PD(A07_cont_PD), .cont(A07_cont__CORE), .P_minus1_PU[0](A07_P_minus1_PU[0]), .P_minus1_PD[0](A07_P_minus1_PD[0]), .P_minus1[0](A07_P_minus1[0]__CORE), .P_minus1_PU[1](A07_P_minus1_PU[1]), .P_minus1_PD[1](A07_P_minus1_PD[1]), .P_minus1[1](A07_P_minus1[1]__CORE), .P_minus1_PU[2](A07_P_minus1_PU[2]), .P_minus1_PD[2](A07_P_minus1_PD[2]), .P_minus1[2](A07_P_minus1[2]__CORE), .y_bit_CS(A07_y_bit_CS), .y_bit_SL(A07_y_bit_SL), .y_bit_IE(A07_y_bit_IE), .y_bit_OE(A07_y_bit_OE), .y_bit_PU(A07_y_bit_PU), .y_bit_PD(A07_y_bit_PD), .y_bit_OUT(A07_y_bit_OUT), .y_bit_PDRV0(A07_y_bit_PDRV0), .y_bit_PDRV1(A07_y_bit_PDRV1), .y_bit_IN(A07_y_bit_IN), .done_CS(A07_done_CS), .done_SL(A07_done_SL), .done_IE(A07_done_IE), .done_OE(A07_done_OE), .done_PU(A07_done_PU), .done_PD(A07_done_PD), .done_OUT(A07_done_OUT), .done_PDRV0(A07_done_PDRV0), .done_PDRV1(A07_done_PDRV1), .done_IN(A07_done_IN), .busy_CS(A07_busy_CS), .busy_SL(A07_busy_SL), .busy_IE(A07_busy_IE), .busy_OE(A07_busy_OE), .busy_PU(A07_busy_PU), .busy_PD(A07_busy_PD), .busy_OUT(A07_busy_OUT), .busy_PDRV0(A07_busy_PDRV0), .busy_PDRV1(A07_busy_PDRV1), .busy_IN(A07_busy_IN), .VDD(A07_VDD));
endmodule
